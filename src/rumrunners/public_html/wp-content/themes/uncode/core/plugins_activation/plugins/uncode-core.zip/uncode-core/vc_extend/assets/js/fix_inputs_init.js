!function($) {
    "use strict";

    window.fixallInputs();

}(window.jQuery);