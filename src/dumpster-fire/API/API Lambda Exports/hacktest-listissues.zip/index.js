/*
    This function gathers all of the submitted issues that are available in the DynamoDB and returns them as a JSON string.
*/

var AWS = require("aws-sdk");   // Bring in the AWS SDK
var docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'}); // Create the DynamoDB object handler
var params = { // Create the parameter variable set to submit the Query to DynamoDB
    TableName: 'Hacktest'   // Name of the table
};
exports.handler = function( event, context, callback ) {     // Enable the callback handler to pass data out to the API endpoint
    docClient.scan(params, function(err, data){ // Begin executing the query to DynamoDB
        if (err) console.log(err);  // Return a usable error if the query can't be executed
        else callback(null, data.Items); // If the query was executed without errors return the resulting table information
    });
}