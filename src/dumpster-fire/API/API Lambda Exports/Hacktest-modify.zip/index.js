/*
    This function creates an issue submitted by a user.
    The requirements of this endpoint are:
        Headers must specify the Content-type: application.json
        The body object submitted for the post must mach the post-model.json format
    A successful POST made using this function will return the issueID number that was
    created for the submitted issue
*/  

console.log('Writing Data');    // Notify testing that data is going to be written
const AWS = require('aws-sdk'); // Bring in the AWS DSK
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});   
    // Create the DynamoDB object handler

exports.handler = function(event, context, callback) {  // Enable the callback handler to pass data out to the API endpoint
    var p = {   // Create the parameter variable set to submit the Query to DynamoDB
        TableName: 'Hacktest',  // Name of the table
        Select: 'COUNT' // Get the number of documents in the table
    };
    docClient.scan(p, function(err, data) { // Begin executing the query to DynamoDB
        var issueID = data.Count;  // Get the count of current documents
        issueID++;  // Increment the issueID to use the next available issueID number
        issueID = ""+issueID;   // Convert the issueID back to a string
        var params = {  // Create the parameter varialbe set to submit the Query to DynamoDB
		Item: {
			issueID: issueID,  // use the new issueID to auto increment
			issueName: event.body.issueName,    // the Title of the issue being submitted
			Topic: event.body.Topic,    // what the issue is regarding
			Lat: event.body.Lat,    // Geolocation lattitude for the location being submitted
			Long: event.body.Long, // Geolocation longitude for the location being submitted
			Tags: event.body.Tags,  // Category tags to group similar issues that might relate
			Summary: event.body.Summary,    // Brief summary of the issue being submitted
			Author: event.body.Author, // The name of the person submitting the Issue
			Story: event.body.Story,    // The entire story about the issue at hand
			Votes: 0,   // Number of votes supporting the submitted issue
			Creator: event.body.Creator,    // The userID that created the issue
			voteUsers: "[]",    // UserID's that support the issue
			createdDate: event.body.createdDate // The date the issue was created
		},
		TableName: 'Hacktest'   // Name of the table
	};
	docClient.put(params, function(err, data) { // Begin executing the query to DynamoDB
		if(err) {
			callback(err, null);    // Return a usable error if the query can't be executed
		} else {
			const response = {  // If the query was executed without errors return a message that it was submitted and the resulting issueID number
			  statusCode: 200,
			  headers: {
				'Access-Control-Allow-Origin' : '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Credentials' : true,
                'Content-Type': 'application/json'
			  },
			  body: JSON.stringify({"message": "Issue Submitted Succesfully","id": issueID})
			};
			callback(null, response);
		}
	});
        
        
        
        
        
        
        
        
        
        
    });
};