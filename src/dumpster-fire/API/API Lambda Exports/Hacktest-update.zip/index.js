/*
    This function is used to vote for an issue that has been submitted. Users can't vote for the same issue twice.
*/

console.log('Writing Data');    // Notify testing that data is being written
const AWS = require('aws-sdk'); // Bring in the AWS SDK
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});   // Create the DynamoDB object handler

exports.handler = function(event, context, callback) {  // Enable the callback handler to pass data out to the API endpoint
    if (event.body.voteUsers) {  // Check to see if the submitting user has already voted
		var p = {
			TableName: "Hacktest",
			Key:{
				"issueID": event.body.issueID
			}
		};
		docClient.get(p,function(err, data) {   // Begin executing the query to DynamoDB
			if (err) {
				console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));    // Return a usable error if the query can't be executed
			} else {    // Gather the current number of votes and increment by 1
				var item = data.Item;
				var newUser = event.body.voteUsers;
				var Votes = item.Votes;
				Votes = Votes + 1;
				var users = JSON.parse(item.voteUsers);
				if (users.indexOf(event.body.voteUsers) === -1) {
					users.push(newUser);
					users = JSON.stringify(users);
					var params = {  // Create the parameter variable set to submit the Query to DynamoDB
						TableName: "Hacktest",  // Name of the table
						Key:{
							"issueID": event.body.issueID
						},
						UpdateExpression: "set Votes=:Votes, voteUsers=:users",
						ExpressionAttributeValues:{
							":Votes": Votes,
							":users": users
						},
						ReturnValues:"UPDATED_NEW"
					}
					docClient.update(params, function(err, data) {
						if(err) {
							callback(err, null);
						} else {
							const response = {
							  statusCode: 200,
							  headers: {
								'Access-Control-Allow-Origin' : '*',
								'Access-Control-Allow-Headers': '*',
								'Access-Control-Allow-Credentials' : true,
								'Content-Type': 'application/json'
							  },
							  body: JSON.stringify({ "message": "Vote Submitted" }) // Notify the consumer that their vote has been counted
							};
							callback(null, response);   //  Return the message
						}
					});
				} else {
					var response = "Error - User has already voted";    // Return a useful reason why the vote could not be made
					callback(null, response);
				}
			}
		});
	} else {
		var response = JSON.stringify("Error - User ID not present in request");    // The submitted userID field was empty
		callback(null, response);
	}
};