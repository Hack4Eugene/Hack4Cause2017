/*
    This function gathers information from DynamoDB for the specific issue ID the API consumer is interested in.
    It expects to receive the issueID number as a query string submitted to the endpoint using the key 'id'
*/

console.log('Gathering Data'); // Notify testing that data is being gathered for the query
const AWS = require('aws-sdk'); // Bring in the AWS SDK
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});  // Create the DynamoDB object handler

exports.handler = function(event, context, callback) {  // Enable the callback handler to pass data out to the API endpoint
    var p = {  // Create the parameter variable set to submit the Query to DynamoDB
        TableName: "Hacktest",  // Name of the table
        Key:{
            "issueID": event.params.querystring.id  // Get the issue ID from the submitted body made to the API
        }
    };
    docClient.get(p,function(err, data) {  // Begin executing the query to DynamoDB
        if (err) {
            console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));  // Return a usable error if the query can't be executed
        } else {	// If the query was executed without errors return the resulting table row information
            var item = data.Item;
            callback(null,item);	// Return the JSON object to the API consumer
        }
    });
}